﻿using Microsoft.AspNetCore.Mvc.Rendering;
using QAForum.EF;
using QAForum.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewModels
{
    public class PostWriteViewModel
    {
        [Display(Name = "Thread")]
        public int ThreadId { get; set; }
        public string Title { get; set; }

        [Display(Name = "User Name")]
        public string UserName { get; set; }

        [Display(Name = "Post Body")]
        public string PostBody { get; set; }

        [Display(Name = "Date of Post")]
        public DateTime PostDateTime { get; set; }

        public IEnumerable<SelectListItem> ThreadSelectListItems { get; set; }


        public static PostWriteViewModel FromPost(Post post, ForumDbContext context)
        {
            return new PostWriteViewModel
            {
                ThreadId = post.ThreadId,
                Title = post.Title,
                UserName = post.UserName,
                PostBody = post.PostBody,
                PostDateTime = post.PostDateTime,
                ThreadSelectListItems = context.GetThreadsSelectListItems(post.ThreadId)
            };
        }

        public static PostWriteViewModel WithThreadSelectListItems(ForumDbContext context)
        {
            return new PostWriteViewModel { ThreadSelectListItems = context.GetThreadsSelectListItems() };
        }
    }
}
