﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickTour.Models
{
    public interface IForumContext
    {
        public IEnumerable<Forum> GetForums();
    }
}
