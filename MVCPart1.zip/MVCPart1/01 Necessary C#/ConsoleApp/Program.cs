﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Planet
    {
        public string Name { get;set;}
        public double DistanceFromSun { get;set;}
        public double Diameter { get;set;}
    }
    class Program
    {
        static List<Planet> planets = new List<Planet>()
        {
            new Planet() { Name="Mercury", DistanceFromSun=36, Diameter=3_031},
            new Planet() { Name="Venus", DistanceFromSun=67.2, Diameter=7_521},
            new Planet() { Name="Earth", DistanceFromSun=93, Diameter=7_926},
            new Planet() { Name="Mars", DistanceFromSun=141.6, Diameter=4_222},
            new Planet() { Name="Jupiter", DistanceFromSun=483.8, Diameter=88_729},
            new Planet() { Name="Saturn", DistanceFromSun=886.7, Diameter=74_000},
            new Planet() { Name="Uranus", DistanceFromSun=1784, Diameter=32_000},
            new Planet() { Name="Neptune", DistanceFromSun=2794.4, Diameter=30_200},
            new Planet() { Name="Saturn", DistanceFromSun=886.7, Diameter=74_000}
        };
        [STAThread]
        static void Main(string[] args) 
        {
            Console.WriteLine("\n--- Lambdas ---");
            foreach (var planet in planets.FindAll(p=>p.DistanceFromSun<100))
            {
                Console.WriteLine($"Name = {planet.Name}, distance from sun = {planet.DistanceFromSun}, diameter = {planet.Diameter}");
            }


            Console.WriteLine("\n--- LINQ ---");
            foreach (var planet in planets.OrderBy(p=>p.Diameter))
            {
                Console.WriteLine($"Name = {planet.Name}, distance from sun = {planet.DistanceFromSun}, diameter = {planet.Diameter}");
            }


            Console.WriteLine("\n--- Dictionary syntax ---");
            Dictionary<string, Planet> dictPlanets = new Dictionary<string, Planet>()
            {
                ["Mercury"]  = new Planet() { Name="Mercury", DistanceFromSun=36, Diameter=3_031},
                ["Venus"] = new Planet() { Name="Venus", DistanceFromSun=67.2, Diameter=7_521},
                ["Earth"] = new Planet() { Name="Earth", DistanceFromSun=93, Diameter=7_926},
                ["Mars"] = new Planet() { Name="Mars", DistanceFromSun=141.6, Diameter=4_222},
                ["Jupiter"] = new Planet() { Name="Jupiter", DistanceFromSun=483.8, Diameter=88_729},
                ["Saturn"] = new Planet() { Name="Saturn", DistanceFromSun=886.7, Diameter=74_000},
                ["Uranus"] = new Planet() { Name="Uranus", DistanceFromSun=1784, Diameter=32_000},
                ["Neptune"] = new Planet() { Name="Neptune", DistanceFromSun=2794.4, Diameter=30_200},
                ["Saturn"] = new Planet() { Name="Saturn", DistanceFromSun=886.7, Diameter=74_000}
            };
            Console.WriteLine("distance of earth from sun" + dictPlanets["Earth"].DistanceFromSun);


            Console.WriteLine("\n--- anonymous type ---");
            var x = new { width = 20, font = "Arial" };

            Console.WriteLine("\n--- dynamic type ---");
            dynamic viewbag = "first we're a string";
            Console.WriteLine($"number of characters = {viewbag.Length}");
            viewbag = new DateTime(2019,12,25);   // now we're a DateTime
            Console.WriteLine(viewbag.ToShortDateString());

            Console.WriteLine("\n--- @variable ---");
            var y = new { width = 20, font = "Arial", @class="btn btn-primary" };

            Console.WriteLine("\n--- Delegate for chaining ---");
            // assume this next line has been set up in the initialization somewhere
            Action NextInChain = new Action(() => { Console.WriteLine("Next in chain"); });
            Console.WriteLine("before delegate call");
            NextInChain.Invoke();
            Console.WriteLine("after delegate call");

            Console.WriteLine("\n--- Task ---");
            Console.WriteLine($"Main Thread = {Thread.CurrentThread.ManagedThreadId}");
            Task.Run( () => {
                //throw new Exception("Oops");
                Console.WriteLine($"Other Thread = {Thread.CurrentThread.ManagedThreadId}");
            });          
            Console.ReadLine();


            Console.WriteLine("\n--- async/await ---");
            RunAsync();
            Console.WriteLine("Do other useful stuff");
            Console.ReadLine();

            Console.WriteLine("\n--- Dispose() ---");
            DbContext ctx = null;
            try { 
                ctx = new DbContext();
            } finally { 
                ctx?.Dispose();
            }
            // or
            using(DbContext ctx2 = new DbContext())
            {

            }

            Console.WriteLine("\n--- IEqualityComparer ---");
            List<Forum> forums1 = new List<Forum> { new Forum() { Title = "Burke and Hare" } };
            List<Forum> forums2 = new List<Forum> { new Forum() { Title = "Burke and Hare" } };
            Console.WriteLine($"are these 2 lists of forums 'equal'...{forums1.SequenceEqual(forums2, new ForumComparer())}");

            Console.WriteLine("end...press c/r to quit");
            Console.ReadLine();
        }

        public static async void RunAsync()
        {
            string textEntered = await Task.Run(() => { 
                Console.WriteLine("press c/r"); 
                return Console.ReadLine(); 
            });
            Console.WriteLine($"process the text entered :{textEntered}");
        }
    }

    public class DbContext : IDisposable
    {
        public void Dispose()
        {         
        }
    }

    // IEqualityComparer<T>
    public class Forum
    {
        public int ForumId { get; set; }
        public string Title { get; set; }
    }
    public class ForumComparer : IEqualityComparer<Forum>
    {

        public bool Equals(Forum x, Forum y)
        {
            if (x.Title == y.Title) return true;

            return false;
        }

        public int GetHashCode(Forum obj)
        {
            return obj.Title.Length;
        }
    }
}
