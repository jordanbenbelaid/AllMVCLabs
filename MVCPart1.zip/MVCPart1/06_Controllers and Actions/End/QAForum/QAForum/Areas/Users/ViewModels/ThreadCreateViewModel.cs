﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewModels
{
    public class ThreadCreateViewModel
    {
        public string Title { get; set; }
        public int ForumId { get; set; }
        public string UserName { get; set; }
        public bool AddWelcomePost { get; set; }
    }

}
