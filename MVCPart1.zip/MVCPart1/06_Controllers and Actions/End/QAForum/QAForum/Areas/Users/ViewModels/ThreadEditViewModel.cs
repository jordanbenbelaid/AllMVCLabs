﻿using QAForum.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewModels
{
    public class ThreadEditViewModel
    {
        public string Title { get; set; }
        public int ForumId { get; set; }
        public string UserName { get; set; }

        public static ThreadEditViewModel FromThread(Models.Thread thread)
        {
            return new ThreadEditViewModel
            {
                Title = thread.Title,
                ForumId = thread.ForumId,
                UserName = thread.UserName
            };
        }
    }
}
