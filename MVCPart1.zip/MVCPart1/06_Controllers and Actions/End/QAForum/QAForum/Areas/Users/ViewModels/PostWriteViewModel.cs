﻿using QAForum.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewModels
{
    public class PostWriteViewModel
    {
        public int ThreadId { get; set; }
        public string Title { get; set; }
        public string UserName { get; set; }
        public string PostBody { get; set; }
        public DateTime PostDateTime { get; set; }

        public static PostWriteViewModel FromPost(Post post)
        {
            return new PostWriteViewModel
            {
                ThreadId = post.ThreadId,
                Title = post.Title,
                UserName = post.UserName,
                PostBody = post.PostBody,
                PostDateTime = post.PostDateTime
            };
        }
    }
}
